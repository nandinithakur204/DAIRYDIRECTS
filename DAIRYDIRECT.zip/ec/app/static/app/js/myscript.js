$('.plus-cart').click(function()
{
    console.log(this.parentNode)
})